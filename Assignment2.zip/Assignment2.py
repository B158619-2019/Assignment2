#!/usr/bin/python3
import os
import sys

'''
For biologistss:

This programme can help you to search for sequences of specific taconomic and protein family in NCBI. EMBOSS tools need to be installed advance to support this programme. More details for EMBOSS please see "http://emboss.sourceforge.net".

To use this programme, run it with python command "python3 Assignment2.py" and follow the instuctions. All the nessecery results will be saved in the current working directory so better keep the current directory empty before using this programme.

-------------------------------------------------------
An example for running this programme (and can also tests if it is working):

	Enter "Aves" when asked "What taconomic group you want to query?"
	Enter "glucose-6-phosphatase" when asked "What protein family you want to query?"
	The programme then starts to looking for the sequences on NCBI and downloads all the sequences in Aves.glucose-6-phosphatase.fasta in fasta format.
	Next, it will run clustalo to get the alignment results and saves in Aves.glucose-6-phosphatase.clustalo.fasta
	Fllowing, it runs plotcon to show a plot to you the similarity between the sequences. The imagine is saved in Aves.glucose-6-phosphatase.ps for furthur use.
	Extral, if you want to find some related motifs in already-known proteins with a specific sequence, enter 'y' and enter the sequence name, the results will show on the screen. However, no file will be saved this time so record the results you want to save.
-------------------------------------------------------

If you go back to this programme later, you can also skip the finding sequences part and start to find the motifs. Just keep the "*.fasta" file in the working directory and tell the programme what is that file and what is the sequence name.






For programmers (maintenance manual):

This programme can help you to search for sequences of specific taconomic and protein family in NCBI. EMBOSS tools need to be installed advance to support this programme.

There are two functions. NCBI() helps to find the sequences of specific taconomic and protein family in NCBI and motif() helps to find if there are any known motifs in a specific sequence at PROSITE

You can skip the "input" part. Type in the variable value you need directly at the begining of the programme. If leave it blank then you will be asked to input that while executing.

This programme can not only be used in protein database. Change the variabe 'database' to the database you want. 

'''


print('This script requires EMBOSS tools. PLease make sure you have installed in correctly')
file_name = ''
taconomic = ''
protein_family = ''
database = 'protein'

# A function to find sequences on NCBI
def NCBI():
	# Ask the user to input the taconomic group and protein family that are wanted to be queried
	global taconomic
	if taconomic == '':
		taconomic = input("What taconomic group you want to query?")
	global protein_family
	if protein_family == '':
		protein_family = input("What protein family you want to query?")
	global file_name
	file_name = taconomic + '.' + protein_family
	global database

	# Do esearch and efetch to get the sequences data into a fasta format

	os.system('esearch -db '+database+' -query "' + taconomic + '[Organism] AND (' + protein_family + ')" | efetch -db '+database+' -format fasta > ' + file_name + '.fasta')

	# Flow control
	print('Sequences data have been saved in ' + file_name + '.fasta \n')

	# Do clustalo to the sequences

	os.system('clustalo -i ' + file_name + '.fasta -o ' + file_name + '.clustalo.fasta')
	print('Clustalo results have been saved in ' + file_name + '.clustalo.fasta \n')

	# Do plotcon to show the similarity between the sequences and show it to the user
	# Windows size choose 20, which can be changed

	os.system('plotcon -winsize 20 -graph ps ' + file_name+ '.clustalo.fasta')
	os.system('evince plotcon.ps')

	# Save the imagine
	os.system('rm plotcon.ps '+file_name+'.ps')
	print('Your image has been saved in '+file_name+'.ps \n')


# Ask the user if wanted to do the searching. If not, can go straight to find the related motifs in known proteins.
choice_of_NCBI = ('Do you want to find sequences on NCBI? Enter "y" if wanted.')
if choice_of_NCBI == 'y':
	NCBI()


# A function to get the chosen sequence in a seperate file
def motif(input1):
	
	# Let the user input what they what gene they wants to compare
	seq_name = input("Please enter the sequence name that you want to compare with PROSITE:")

	# Get the chosen sequence.
	all_sequences = open(input1).read().split('>')
	selection = ''
	for a in all_sequences:
		if a[0:10] == seq_name:
			selection = a

	# Write the chosen sequence in a seperate file. If there is no sequences available, report and end.
	if selection != '':
		my_outfile = open(seq_name + ".txt", "w")
		my_outfile.write('>' + selection)
		my_outfile.close()
	else:
		print("No matched sequences were found. PLease check your input \n")
		return 0

	# If there is a match sequence, do the patamatmotifs in EMBOSS to find the matched motifs.		
	os.system('patmatmotifs -sequence ' + seq_name + '.txt -outfile ' + seq_name + '.patmatmotifs')
	os.system('rm ' + seq_name + '.txt')
	os.system('more '+seq_name+'.patmatmotifs')
	os.system('rm '+seq_name+'.patmatmotifs')
	return 0

# For teacher to test this function, use the following and input CAG31453.1:
# Make sure the Aves.glucose-6-phosphatase.fasta already exists
'''
taconomic = "Aves"
protein_family = 'glucose-6-phosphatase'
file_name = taconomic + '.' + protein_family
motif(file_name + ".fasta")
'''

# Ask the user if wanted to do the motifs part
choice_of_motifs = input("Do you want to find the motifs for a specific gene? Enter 'y' or 'n'\nPlease notice that you need to use this programme to generates sequences files and use EMBOSS prosextract first before carrying on.\nFor more information about EMBOSS see http://www.sacs.ucsf.edu/Documentation/emboss/prosextract.html")
if choice_of_motifs == 'y' or 'Y':
	# if the user hasn't run the NCBI() before, ask for the file name.
	if file_name == '':
		file_name = input("Please enter the file name that includes your aim sequences. Don't include the '.fasta'")

	# Allow the user to test many sequences at once
	x = 'y'
	while x == 'y':
		motif(file_name + ".fasta")
		x = input('Do you want to test another sequence? Enter "y" if wanted.')





